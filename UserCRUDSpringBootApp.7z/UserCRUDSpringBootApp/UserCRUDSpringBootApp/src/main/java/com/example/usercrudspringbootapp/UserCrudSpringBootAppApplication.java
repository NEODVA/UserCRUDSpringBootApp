package com.example.usercrudspringbootapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserCrudSpringBootAppApplication {

    public static void main(String[] args) {

        SpringApplication.run(UserCrudSpringBootAppApplication.class, args);
    }

}
